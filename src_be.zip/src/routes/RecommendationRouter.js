const express = require("express");
const router = express.Router();
const {
  getRecommendations,
} = require("../controllers/RecommendationController");

router.get("/get-recommend/:id", getRecommendations);

module.exports = router;
