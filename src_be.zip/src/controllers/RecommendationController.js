const mongoose = require("mongoose");
const { recommend } = require("../services/RecommendationService");

const getRecommendations = async (req, res) => {
  try {
    const userId = req.params.userId;
    const productIds = await recommend(userId);
    const products = await mongoose
      .model("Product")
      .find({ _id: { $in: productIds } });
    res.json(products);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

module.exports = { getRecommendations };
